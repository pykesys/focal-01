class TestVgg16ImageSearchService:
    # TODO add tests
    def test_pass(self):
        assert True
